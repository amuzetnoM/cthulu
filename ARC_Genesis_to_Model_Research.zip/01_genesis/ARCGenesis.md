ARC GENESIS
-----------
ARCGenesis is the immutable root of trust.
Properties:
- No storage
- No admin
- No upgrade
- Pure constants only
- Canonical codehash anchoring the entire ecosystem

Purpose:
- Establishes the laws of the ARC system
- Every downstream contract must reference and validate this genesis