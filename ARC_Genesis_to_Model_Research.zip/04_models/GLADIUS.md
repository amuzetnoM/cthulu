GLADIUS MODEL
-------------
Role: Enterprise execution & orchestration model

Capabilities:
- Infrastructure decision execution
- Governance proposal authoring
- Parameter enforcement
- Emergency coordination

Constraints:
- Requires ARCModelSBT
- Governed by ARC Governor
- Subject to slashing / revocation