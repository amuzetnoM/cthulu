ARC Research Repository
Scope: ARC Genesis → Registries → Models → Roles (Jobs)
Version: v1.0-beta
Date: 2026-01-17
This repository documents the full trust chain, research rationale, and architectural decisions.